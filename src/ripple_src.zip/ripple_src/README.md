#ripple
###Installation instructions

+ download [midi patchbay](http://notahat.com/midi_patchbay/ "midi patchbay")
+ open *ripple_routing.mpb* to create the routing
+ launch ripple.app

###Compile instructions
+ create a new OF project, include ofxMaxim, ofxGui, and [ofxMidi](https://github.com/danomatika/ofxMidi "ofxMidi")
+ replace everything in */src* with the ripple source files and include in xcode project
+ run
