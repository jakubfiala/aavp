#pragma once

#include "ofMain.h"
#include "ofxMaxim.h"
#include <vector>
#include <deque>

/* UNKNOWN PLEASURIFIER
    this little app transforms live sound input into a nice graphic
    reminiscent of the album cover of Unknown Pleasures by Joy Division
    that you can take a screenshot of by pressing any key and find it
    in your bin/data directory or wherever it will get saved.
    I hold no copyright to the graphic style, and I'm sorry if Joy Division are offended
    by this.
    Oh wait.
    They don't exist anymore ;)
 */


class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();

		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);
    
    void audioRequested 	(float * input, int bufferSize, int nChannels);
    void audioReceived 	(float * input, int bufferSize, int nChannels);

    //double-ended queue of float buffers
    deque<vector<float> > forms;
    maxiFFT fft;
    ofImage img; //this is for taking screenshots
    float offset; //offset of the graphic from the edge of the screen
    int imgCount; //how many screenshots have we taken?
    string prefix = "UnknownPleasure"; //filename stuff
    string suffix = ".png";
		
};
