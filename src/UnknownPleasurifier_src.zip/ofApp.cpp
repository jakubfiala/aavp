#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    ofSetVerticalSync(true);
    
    //fill our buffers with zeros
    for (int y = 0; y < 20; y++){
        vector<float> v;
        forms.push_back(v);
        for (int x = 0; x < 512; x++){
            forms[y].push_back(0);
        }
    }
    
    //setup vars
    offset = 100;
    imgCount = 0;
    
    
    //setup fft
    fft.setup(1024, 1024, 1024);
    
    ofSoundStreamSetup(2, 2, 44100, 1024, 4);
}

//--------------------------------------------------------------
void ofApp::update(){

}

//--------------------------------------------------------------
void ofApp::draw(){
    ofBackground(0);
    ofSetColor(255);
    //display interpolated spectrum bins for each buffer, but take only the first 100 bins
    //and space them by 4 pixels so it looks nicer
    //also space by 20 vertically
    for (int y = 0; y < forms.size()-1; y++){
        for (int x = 0; x < 100; x++){
            float base = (y+1)*20+offset;
            float val = (float) ofMap(forms[y][x], 0, 10, 0, 18);
            float prevval = (float) ofMap(forms[y][x-1], 0, 10, 0, 18);
            ofLine(x*4 + offset, base-prevval, x*4+4+offset, base-val);
        }
    }

}

void ofApp::audioRequested 	(float * input, int bufferSize, int nChannels){
    
    
}

void ofApp::audioReceived 	(float * input, int bufferSize, int nChannels){
    
    
    for (int i = 0; i < bufferSize; i++){
        //do fft
        bool isFFT = fft.process(input[i*2]);
        if (isFFT) {
            //remove oldest buffer
            forms.pop_front();
            
            vector<float> v;
            //add stuff to new buffer
            for (int n = 0; n < fft.windowSize; n++)
                v.push_back(fft.magnitudes[n]);
            //add the buffer to our queue
            forms.push_back(v);
        }
        
    }
    
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    //say cheese
    img.grabScreen(0, 0, ofGetWidth(), ofGetHeight());
    //create filename
    char num[21];
    sprintf(num, "%d", ++imgCount);
    string name = prefix  + num + suffix;
    //save
    img.saveImage(name);
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
