#UnknownPleasurifier
###Installation instructions

+ just open UnknownPleasurifier.app

###Compile instructions

+ create a new OF project, include ofxMaxim
+ replace */src* with the one in this directory
+ compile!
