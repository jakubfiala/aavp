#pragma once

#include "ofMain.h"
#include "ofxCvHaarFinder.h"
#include "enemi.h"
#include <vector>
#include <deque>

class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();

		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);
    
    ofVideoGrabber videoGrabber;
    ofxCvHaarFinder faceFinder;
    ofxCvHaarFinder eyeFinder;
    ofImage img;
    ofImage wholeImg;
    ofRectangle catcher;
    
    deque<Enemi> enemis;
    float globalSpeed;
    
    bool gameOn;
    
    ofTrueTypeFont text;
		
};
