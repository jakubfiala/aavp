#the enemi is mi

###Installation instructions

+ no installation needed, just open *theenemiismi.app*

###Compile instructions

+ create a new OF project, include ofxOpenCv
+ replace the project's */bin* and */src* folders with the ones in this directory
+ compile!