//
//  enemi.cpp
//  EverythingIsFace
//
//  Created by Jakub Fiala on 30/12/2014.
//
//

#include "enemi.h"

Enemi::Enemi(ofImage * i, float s)
{
    img = *i;
    y = 0;
    x = 1 + (rand() % (int)(1000 - 1 + 1));
    w = 50 + (rand() % (int)(250 - 50 + 1));
    h = 50 + (rand() % (int)(250 - 50 + 1));
    exists = true;
    speed = s;
}

Enemi::~Enemi()
{
    
}

void Enemi::display()
{
    y += 10*speed;
    img.draw(x, y, w, h);
}