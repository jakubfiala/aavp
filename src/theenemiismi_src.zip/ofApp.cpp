#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    
    //init variables and display stuff
    gameOn = true;
    globalSpeed = 1;
    
    text.loadFont("verdana.ttf", 40);
    
    videoGrabber.setDeviceID(0);
    videoGrabber.setDesiredFrameRate(60);
    videoGrabber.initGrabber(320, 240);
    
    //allocate images
    img.allocate(320, 240, OF_IMAGE_COLOR);
    wholeImg.allocate(320, 240, OF_IMAGE_COLOR);
    
    //setup haar finders
    faceFinder.setup("haarcascade_face.xml");
    eyeFinder.setup("Mouth.xml");
    
    ofSetVerticalSync(true);
}

//--------------------------------------------------------------
void ofApp::update(){
    videoGrabber.update();
    //check if we've got a new frame
    if (videoGrabber.isFrameNew()) {
        //get haar objects
        faceFinder.findHaarObjects(videoGrabber.getPixelsRef());
        eyeFinder.findHaarObjects(videoGrabber.getPixelsRef());

        //if we have objects
        if (faceFinder.blobs.size() > 0 && eyeFinder.blobs.size() > 0) {
            //get video pixels
            ofPixels blobPixels = videoGrabber.getPixelsRef();
            //set position of invisible "catcher" rectangle
            catcher.set(eyeFinder.blobs[0].boundingRect.x*3.2, eyeFinder.blobs[0].boundingRect.y*3.2, eyeFinder.blobs[0].boundingRect.width*3.2, eyeFinder.blobs[0].boundingRect.height*3.2);
            //crop the video pixels to the face
            blobPixels.crop(faceFinder.blobs[0].boundingRect.x, faceFinder.blobs[0].boundingRect.y, faceFinder.blobs[0].boundingRect.width, faceFinder.blobs[0].boundingRect.height);
            //set img to the face
            img.setFromPixels(blobPixels);

        }
    }
}

//--------------------------------------------------------------
void ofApp::draw(){
    //draw cam input
    ofSetHexColor(0xffffff);
    wholeImg.setFromPixels(videoGrabber.getPixelsRef());
    wholeImg.mirror(false, true);
    wholeImg.draw(0,0,1024,768);
    
    
    ofSetColor(0);
    ofFill();
    
    //try to draw an enemi every 20 frames & increase speed
    if (ofGetFrameNum() % 20 == 0 && faceFinder.blobs.size() != 0)
    {
        Enemi enemi = *new Enemi(&img, globalSpeed);
        enemis.push_back(enemi);
        globalSpeed += 0.5;
    }
    
    if (gameOn) {
        if (faceFinder.blobs.size() > 0 && eyeFinder.blobs.size() > 0) {
            
            ofSetHexColor(0xffffff);
            
            //here we'll iterate over the enemi deque (don't ask me how I came up with what custom iterator class to use, it's ridiculous. Thanks, whoever made std::deque an absolute nightmare to work with. It's still the best though.)
            _Deque_iterator<Enemi, Enemi &, Enemi *> it = enemis.begin();
            
            for (int i = 0; i < enemis.size(); i++) {
                
                it++;
                
                //if we have an enemi and we've caught it, erase it
                if (enemis[i].exists && enemis[i].x > catcher.x && enemis[i].x < (catcher.x + catcher.width) && enemis[i].y > catcher.y && enemis[i].y < (catcher.y + catcher.height)) {
                    enemis.erase(it);
                }
                else {
                    //if it reaches the bottom, set game to over
                    enemis[i].display();
                    if ((enemis[i].y + enemis[i].h + 10)> ofGetHeight()) {
                        enemis.erase(it);
                        gameOn = false;
                    }
                }
                
                
            }
            
            
            
        }
    }
    else {
        //game is over
        ofSetColor(255);
        text.drawString("GAME OVER", 30, 100);

    }
    
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    if (key == 32)
    {
        
    }

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
