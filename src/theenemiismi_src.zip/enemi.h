//
//  enemi.h
//  EverythingIsFace
//
//  Created by Jakub Fiala on 30/12/2014.
//
//

#ifndef __EverythingIsFace__enemi__
#define __EverythingIsFace__enemi__

#include <stdio.h>
#include "ofMain.h"
#include <cmath>
#include "random.h"


class Enemi {
public:
    Enemi(ofImage * i, float s);
    ~Enemi();
    void display();
    float x,y,w,h;
    float speed;
    ofImage img;
    bool exists;
};

#endif /* defined(__EverythingIsFace__enemi__) */
