//-------------------------------------------------------------------------------------------------------
// VST Plug-Ins SDK
// Version 2.4		$Date: 2006/11/13 09:08:27 $
//
// Category     : VST 2.x SDK Samples
// Filename     : maxiFX.h
// Created by   : Steinberg Media Technologies
// Description  : Stereo plugin which applies Gain [-oo, 0dB]
//
// © 2006, Steinberg Media Technologies, All Rights Reserved
//-------------------------------------------------------------------------------------------------------

#ifndef __maxiFX__
#define __maxiFX__

#include "public.sdk/source/vst2.x/audioeffectx.h"
#include "maximilian.h"

//-------------------------------------------------------------------------------------------------------
class maxiFX : public AudioEffectX
{
public:
	maxiFX (audioMasterCallback audioMaster);
	~maxiFX ();
    
	// Processing
	virtual void processReplacing (float** inputs, float** outputs, VstInt32 sampleFrames);
    
	// Parameters
	virtual void setParameter (VstInt32 index, float value);
	virtual float getParameter (VstInt32 index);
	virtual void getParameterName (VstInt32 index, char* text);
    virtual VstInt32 canDo (char* text);
    
	virtual bool getEffectName (char* name);
	virtual bool getVendorString (char* text);
	virtual bool getProductString (char* text);
	virtual VstInt32 getVendorVersion ();
    
protected:
    
    
	float fFreq;
	float fRes;
    maxiFilter filt[2];
    convert mtof;
	
};

#endif
