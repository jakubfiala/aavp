//-------------------------------------------------------------------------------------------------------
// VST Plug-Ins SDK
// Version 2.4		$Date: 2006/11/13 09:08:27 $
//
// Category     : VST 2.x SDK Samples
// Filename     : maxiFX.cpp
// Created by   : Steinberg Media Technologies
// Description  : Stereo plugin which applies Gain [-oo, 0dB]
//
// © 2006, Steinberg Media Technologies, All Rights Reserved
//-------------------------------------------------------------------------------------------------------

#include "maxiFX.h"

//-------------------------------------------------------------------------------------------------------
AudioEffect* createEffectInstance (audioMasterCallback audioMaster)
{
	return new maxiFX (audioMaster);
}

//-------------------------------------------------------------------------------------------------------
maxiFX::maxiFX (audioMasterCallback audioMaster)
: AudioEffectX (audioMaster, 1, 1)	// 1 program, 2 parameters
{
    //isSynth();
	setNumInputs (2);		// stereo in
	setNumOutputs (2);		// stereo out
	setUniqueID ('mxfy');	// identify
	canProcessReplacing ();	// supports replacing output
    fFreq = 100;
    fRes = 0.5;
}

//-------------------------------------------------------------------------------------------------------
maxiFX::~maxiFX ()
{
    
	// nothing to do here
}


//-----------------------------------------------------------------------------------------
void maxiFX::setParameter (VstInt32 index, float value)
{
	switch (index)
	{
		case 0:
			fFreq = maxiMap::linexp(value, 0, 1, 20, 15000);
			break;
            
	}
}

//-----------------------------------------------------------------------------------------
float maxiFX::getParameter (VstInt32 index)
{
	switch (index)
	{
		case 0:
			return fFreq;
			break;
            
	}
	return 0.f;
}

//-----------------------------------------------------------------------------------------
void maxiFX::getParameterName (VstInt32 index, char* label)
{
	
	switch (index)
	{
		case 0:
			vst_strncpy (label, "Cutoff", kVstMaxParamStrLen);
			break;
	}
	
}


//------------------------------------------------------------------------
bool maxiFX::getEffectName (char* name)
{
	vst_strncpy (name, "basstomid", kVstMaxEffectNameLen);
	return true;
}

//------------------------------------------------------------------------
bool maxiFX::getProductString (char* text)
{
	vst_strncpy (text, "basstomid", kVstMaxProductStrLen);
	return true;
}

//------------------------------------------------------------------------
bool maxiFX::getVendorString (char* text)
{
	vst_strncpy (text, "fiala", kVstMaxVendorStrLen);
	return true;
}

//-----------------------------------------------------------------------------------------
VstInt32 maxiFX::getVendorVersion ()
{
	return 1000;
}

//-----------------------------------------------------------------------------------------
VstInt32 maxiFX::canDo (char* text)
{
	return -1;	// explicitly can't do; 0 => don't know
}


//-----------------------------------------------------------------------------------------
void maxiFX::processReplacing (float** inputs, float** outputs, VstInt32 sampleFrames)
{
    
    float* in1  =  inputs[0];
    float* in2  =  inputs[1];
    float* out1 = outputs[0];
    float* out2 = outputs[1];
    
    //this is extremely simple – just mix half of L in L and R in R
    //then add a filtered sum of 25% L + 25% R
    //filter freq is controlled by the user
    //doesn't work perfectly but does the job
    for (int i = 0; i < sampleFrames; i++)
    {
        out1[i] = filt[0].hires(in1[i], fFreq, fRes)*0.5 + filt[0].lores(in1[i]*0.25 + in2[i]*0.25, fFreq, fRes);
        out2[i] = filt[1].hires(in2[i], fFreq, fRes)*0.5 + filt[0].lores(in1[i]*0.25 + in2[i]*0.25, fFreq, fRes);
    }
}

