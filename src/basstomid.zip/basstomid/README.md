#Basstomid
###Installation Instructions

+ just open *basstomid.vst* in your favourite DAW

###Compile Instructions

+ open Chris Kiefer's VST maxiFX example, fix all the path stuff, and replace *maxiFX.h* and *.cpp* with the ones in basstomid.