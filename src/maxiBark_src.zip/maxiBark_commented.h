/*
 *  maxiBark.cpp
 *  Bark scale loudness
 *
 *  Created by Jakub on 01/12/2014.
 *  Copyright 2014 Goldsmiths Creative Computing. All rights reserved.
 *
 */

/*  So this is my implementation of the bark scale algorithm we found in YAAFE
 *  and modified for Meyda. It's actually improved as it does all the init stuff
 *  such as creating the bark scale and finding the bark band limits in the setup function
 *  and only performs summation per-band or normalisation in the process functions.
 *
 *  future development might include adding perceptual sharpness and spread, as seen in
 *  yaafe/meyda.
 */
 

#pragma once
#pragma pack(16)

#include "maxiFFT.h"
#include <math.h>
#include <iostream>
//#include <algorithm>
#include <cstdlib>
#ifdef __APPLE_CC__
#include <Accelerate/Accelerate.h>
#endif

using namespace std;

//convert to Bark scale (Zwicker, 1961)
inline double hzToBark(double hz) {
    return 13.0*atan(hz/1315.8) + 3.5*atan(pow((hz/7518.0),2));
}

//convert bin number to hertz
inline double binToHz(unsigned int bin, unsigned int sR, unsigned int bS) {
    return bin*sR/bS;
}

template <class T> //this is something that's done quite often in ofxMaxim classes, so I did it, although it doesn't make too much sense to do templating if maximilian pretty much only works with doubles/floats.

class maxiBarkScaleAnalyser {
public:
    int NUM_BARK_BANDS;
    
    void setup(unsigned int sR, unsigned int bS) {
        //setup vars
        this->sampleRate = sR;
        this->bufferSize = bS;
        specSize = bS/2;
        NUM_BARK_BANDS = 24;
        
        //create bark scale
        for (int i=0; i<specSize; i++) {
            barkScale[i] = hzToBark(binToHz(i, sR, bS));
        }
        
        bbLimits[0] = 0;
        int currentBandEnd = barkScale[specSize-1]/NUM_BARK_BANDS;
        int currentBand = 1;
        //this finds the limits of each bark band
        for(int i = 0; i<specSize; i++){
            while(barkScale[i] > currentBandEnd) {
                bbLimits[currentBand] = i;
                currentBand++;
                currentBandEnd = currentBand*barkScale[specSize-1]/NUM_BARK_BANDS;
            }
        }
        //and the last limit
        bbLimits[NUM_BARK_BANDS] = specSize-1;
    };
    
    double* specificLoudness(float* normalisedSpectrum) {
        //sum each band
        for (int i = 0; i < NUM_BARK_BANDS; i++){
            double sum = 0;
            for (int j = bbLimits[i] ; j < bbLimits[i+1] ; j++) {
                
                sum += normalisedSpectrum[j];
            }
            specific[i] = pow(sum,0.23);
        }
        
        return specific;
    };
    
    double* relativeLoudness(float* normalisedSpectrum) {
        //sum each band
        for (int i = 0; i < NUM_BARK_BANDS; i++){
            double sum = 0;
            for (int j = bbLimits[i] ; j < bbLimits[i+1] ; j++) {
                
                sum += normalisedSpectrum[j];
            }
            specific[i] = pow(sum,0.23);
        }
        //normalise (this might need optimising)
        double max = 0;
        for (int i = 0; i < NUM_BARK_BANDS; i++){
            if (specific[i] > max) max = specific[i];
        }
        
        for (int i = 0; i < NUM_BARK_BANDS; i++){
            relative[i] = specific[i]/max;
        }
        
        return relative;
    };
    
    double* totalLoudness(float* normalisedSpectrum) {
        //sum each band
        for (int i = 0; i < NUM_BARK_BANDS; i++){
            double sum = 0;
            for (int j = bbLimits[i] ; j < bbLimits[i+1] ; j++) {
                
                sum += normalisedSpectrum[j];
            }
            specific[i] = pow(sum,0.23);
        }
        
        //sum all bands
        total[0] = 0;

        for (int i = 0; i < 24; i++){
            total[0] += specific[i];
        }
        
        return total;
    };
    
private:
    int bbLimits[24];
    unsigned int sampleRate, bufferSize, specSize;
    double barkScale[2048];
    double specific[24];
    double relative[24];
    double total[1];
    
};

typedef maxiBarkScaleAnalyser<double> maxiBark;






