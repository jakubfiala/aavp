#maxiBark
###Installation instructions

+ Use the latest version ofxMaxim plugin in your openframeworks project
+ include *maxiBark.h* in your app header file (it comes with ofxMaxim already)

###Usage

+ create a maxiBark object and a maxiFFT
+ call its setup function in your `ofApp::setup()` with your buffer size and sample rate
+ analyze your sound input with maxiFFT, and when its `fft()` function returns `true`, call one of the maxiBark loudness functions with `fft.magnitudes()` as argument
+ this will give you a pointer to a double array of length 24 for specific and relative loudness, and 1 for total loudness